let a = prompt("enter first number");
let b = prompt("enter second number");

alert("Sum for those number is " + (Number(a)+Number(b)))

