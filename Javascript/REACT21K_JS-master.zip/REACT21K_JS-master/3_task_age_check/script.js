let age = prompt("how old are you?");
if (age <= 18) {
    alert("you are too young")
} else {
    alert("welcome")
}
